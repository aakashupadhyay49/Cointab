import { useState } from 'react';
import Data from "../db.js"
import Data2 from "../db2.js"

import './InputField.css'
const InputFeild = () => {
 const [totalPrice, setTotalPrice] = useState(null)
  const [form, setForm] = useState({
    weight:'',
    pincode:'',
    rate_type:'',
    zone:''

  })



function check(pin,zon){
  pin.map((e,i)=>{
    if(pin[i]===form.pincode&&zon[i]===form.zone){
      return true
    }
  })
  return "no"
}

function check2(rate,zon,first,add){
  rate.map((e,i)=>{
    if(rate[i]===form.rate_type&&zon[i]===form.zone){
      return [true,first[i],add[i]]
    }
  })
  return false
}


var ans=''

 Data.map((e)=>{
   ans=check(e.pincode,e.zone)
  //  console.log(ans)
    
 })


var ans2=''
const change=()=>{
  Data2.map((e)=>{
    ans2=check2(e.RateType,e.CourierZone,e.FirstKG,e.EveryAdditionalKG)
    
     
  })
}


console.log(ans2)
if(ans2[0]==true){
  var weight=Math.ceil(form.weight)
  setTotalPrice(0.5*ans2[1]+(weight-0.5)*ans2[2])
}
 
 
  


  const handleChange = (e)=>{
    setForm( (prev) =>({
       ...prev,
       [e.target.name] :e.target.value
       
    }))
    
    
  }

 



  return (
    <div>
     

     <div className="form">
     <form >

<input type="text"  value ={form.weight} onChange={handleChange} name="weight" id="" placeholder="product Weight" required className='input' />
 <br /><br />
 <input type="number"  value ={form.pincode} onChange={handleChange} name="pincode" id="" placeholder="Enter Pincode  507101" required className='input' />
 <span>
 <select name="zone"    className='box' value ={form.zone} onChange={handleChange}   >
    
    
    <option className='input' > Zone </option>
      <option value="a"> a</option>
      <option value="b"> b</option>
      <option value="c"> c</option>
      <option value="d"> d</option>
      <option value="e"> e</option>
    </select>

 </span>
 
 <br /><br />
  <select name="rate_type"    className='input' value ={form.rate_type} onChange={handleChange}   >
    
    
  <option className='input'> Rate Type </option>
    <option value="Forward"   > Forward </option>
    <option value="Forward & RTO"  > Forward & RTO </option>
    
  </select>
  <br /><br />
 <button variant="contained" onClick={change} > Price </button>

</form>
<br /><br /><br />
 {!!totalPrice && `Your Total Prize is  $ ${totalPrice .toFixed(2)}`}
     </div>
    </div>
  )
}

export default InputFeild