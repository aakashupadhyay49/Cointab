
import './App.css';

import InputFeild from './Components/InputField';

function App() {
  return (
    <div className="App">
        <InputFeild/>
    </div>
  );
}

export default App;
