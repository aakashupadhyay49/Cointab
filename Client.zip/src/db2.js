const Data2=[
    {
       "RateType":[
"Forward",
"Forward",
"Forward",
"Forward",
"Forward",
"Forward & RTO",
"Forward & RTO",
"Forward & RTO",
"Forward & RTO",
"Forward & RTO"],

"CourierZone":[
"a",
"b",
"c",
"d",
"e",
"a",
"b",
"c",
"d",
"e"],

"FirstKG":[
"29.5",
"33",
"40.1",
"45.4",
"56.6",
"43.1",
"53.5",
"72",
"86.7",
"107.3"
],

"EveryAdditionalKG":[
"23.6",
"28.3",
"38.9",
"44.8",
"55.5",
"47.2",
"56.6",
"77.8",
"89.6",
"111"]



    }
]

export default Data2